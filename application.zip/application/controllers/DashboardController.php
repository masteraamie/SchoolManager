<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardController extends CI_Controller
{

    public function index()
    {

        $this->check_login();
        $this->load->model("HRModel");
        $this->load->model("AcademicModel");
        $this->load->model("StudentModel");


        $data['employees'] = $this->HRModel->get_employees_count();
        $data['students'] = $this->StudentModel->get_students_count();
        $data['present'] = $this->StudentModel->get_student_attendance_today();
        $data['classes'] = $this->AcademicModel->get_classes_count();

        $this->load->model("NewsModel");
        $data['news'] = $this->NewsModel->get_news();


        $this->load->model("AchievementModel");
        $data['achievements'] = $this->AchievementModel->get_achievements();

        $this->load->model("EventModel");
        $data['events'] = $this->EventModel->get_events();

        $this->load->model("AdminMessageModel");
        $data['unread_messages'] = $this->AdminMessageModel->get_unread_messages();
        $data['unread_count'] = is_array($data['unread_messages']) ? count($data['unread_messages']) : 0;

        $this->load->view('admin/AdminDashboard', $data);

    }

    public function check_login()
    {
        if($this->session->has_userdata('admin_username') && $this->session->has_userdata('admin_login_time'))
        {
            $this->load->model("LoginModel");
            $admin = $this->LoginModel->check_session_username($_SESSION['admin_username']);

            if(!$admin)
                redirect(site_url("Login/"));

        }
        else
        {
            redirect(site_url("Login/"));
        }
    }


    public function get_presents()
    {

    }



}
