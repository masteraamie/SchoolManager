<!DOCTYPE html>
<html lang="en">
<head>

    <!--[if IE]>
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <title>Srinagar British School</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="icon" type="image/png" href="<?= base_url(); ?>assets/assets/images/favicon.png">

    <!-- CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/assets/css/animate.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/assets/css/master.css">


    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400" rel="stylesheet">


    <style>

        body {
            overflow-x: hidden;
        }

        #events {
            background-color: #E4E4E4;
            padding-top: 50px;
            padding-bottom: 50px;
        }

        #events a {
            color: #000;
            font-family: "Montserrat", sans-serif;
            font-weight: 400;
            font-size: 14px;
        }

        #latest_visits {
            margin-top: 30px;
            margin-bottom: 60px;
            background-color: #eeeeee;
            padding: 30px 0;
        }

        #latest_visits .card {
            box-shadow: 5px 5px 10px 0 #dadada;
            border: 0;
            border-radius: 0;
            margin-bottom: 10px;
            text-align: center;
            transition: all 300ms;
        }

        #latest_visits .card:hover {
            transform: rotate(4deg) scale(1.1);
            box-shadow: 25px 25px 30px 0 #cccccc;
        }

        #latest_visits .card .btn {
            border-radius: 0;
        }

        #latest_visits h4 {
            font-family: "Montserrat", sans-serif;
            font-size: 18px;
            color: #000;
            margin-top: 20px;
            margin-bottom: 3px;
        }

        #latest_visits p {
            font-family: "Lato", sans-serif;
            color: #5d5d63;
            margin-top: 0;
            padding-top: 0;
        }

        .carousel img {
            width: 100% !important;
            height: 100% !important;
        }

        #header {
            position: absolute;
            z-index: 10;
            width: 100%;
            background: rgba(3, 53, 111, 0.89);
            font-family: "Montserrat", sans-serif;
            font-weight: 300;
        }

        #footer .nav-item > a {
            color: #fff;
            font-size: 15px;
            margin-left: 15px;
        }

        #header .nav-item > a {
            color: #fff;
            font-size: 15px;
            margin-left: 15px;
        }


        #testimonials {
            background-color: #174b81 !important;
            color: #ffffff !important;
        }


        @media only screen and (max-width: 750px) {
            #events .card .col-lg-8 {
                margin-top: 20px;
                text-align: center;
            }

        }

    </style>


</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=1847243852190281";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>



<?php
$this->load->view('frontend/header');
?>


<div id="slider">

    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">

                <?php

                if (!empty($images[0]['Image1'])) {
                    echo '<img class="d-block img-fluid" src="' . base_url() . $images[0]['Image1'] . '" alt="First slide">';
                } else {
                    echo '<img class="d-block img-fluid" src="' . base_url("assets/assets/images/slide1.jpg") . '" alt="First slide">';
                }

                ?>

            </div>
            <div class="carousel-item">
                <?php

                if (!empty($images[0]['Image2'])) {
                    echo '<img class="d-block img-fluid" src="' . base_url() . $images[0]['Image2'] . '" alt="First slide">';
                } else {
                    echo '<img class="d-block img-fluid" src="' . base_url("assets/assets/images/slide1.jpg") . '" alt="First slide">';
                }

                ?>
            </div>
            <div class="carousel-item">
                <?php

                if (!empty($images[0]['Image3'])) {
                    echo '<img class="d-block img-fluid" src="' . base_url() . $images[0]['Image3'] . '" alt="First slide">';
                } else {
                    echo '<img class="d-block img-fluid" src="' . base_url("assets/assets/images/slide1.jpg") . '" alt="First slide">';
                }

                ?>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

</div>

<div id="events">

    <div class="container">

        <div class="row">

            <div class="col-12 card-deck">

                <div class="card">
                    <div class="card-header">LATEST NEWS</div>
                    <div class="card-block">

                        <?php

                        if (isset($news)) {
                            foreach ($news as $e) {

                                echo '<div class="row mb-4">';

                                echo '<div class="col-3">';
                                echo '<img src="' . $e['Image'] . '" class="img-fluid">';
                                echo '</div>';
                                echo ' <div class="col-9"><a href="">';
                                echo $e['Title'];


                                $date = date_create($e['Date']);

                                echo '<br/><i class="fa fa-calendar"></i> ' . date_format($date, "d M Y");
                                echo '</a></div></div>';
                            }
                        }

                        ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">LATEST EVENTS</div>
                    <div class="card-block">
                        <?php

                        if (isset($events)) {
                            foreach ($events as $e) {

                                echo '<div class="row mb-4">';
                                echo '<div class="col-3">';
                                echo '<img src="" class="img-fluid">';
                                echo '</div>';
                                echo ' <div class="col-9"><a href="">';
                                echo $e['Name'];
                                $date = date_create($e['StartDate']);

                                echo '<br/><i class="fa fa-calendar"></i> ' . date_format($date, "d M Y");
                                echo '</a></div></div>';
                            }
                        }

                        ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">LATEST ACHIEVEMENTS</div>
                    <div class="card-block">
                        <?php

                        if (isset($achievements)) {
                            foreach ($achievements as $e) {

                                echo '<div class="row mb-4">';
                                echo '<div class="col-3">';
                                echo '<img src="' . $e['Image'] . '" class="img-fluid">';
                                echo '</div>';
                                echo ' <div class="col-9"><a href="">';
                                echo $e['Title'];
                                echo '<br/><i class="fa fa-user"></i> ' . $e['AchievementBy'];
                                echo '</a></div></div>';
                            }
                        }

                        ?>
                    </div>
                </div>

            </div>

        </div>

    </div>

</div>

<div id="latest_visits">

    <div class="container">

        <div class="row">

            <div class="col-lg-12 mb-3">
                <h1>Latest Visits<span class="heading-border"></span></h1>
            </div>

            <div class="col-lg-12 card-deck">


                <?php

                if (isset($visits)) {
                    foreach ($visits as $e) {

                        echo '<div class="card">';
                        echo '<div class="card-block">';
                        echo '<img src="' . $e['Image'] . '" class="img-fluid">';
                        echo "<h4>" . $e['VisitBy'] . "</h4>";
                        echo "<p>" . $e['Designation'] . "</p>";
                        echo '<a href="" class="btn btn-primary btn-sm">VIEW DETAILS</a>';
                        echo '</div>';
                        echo '</div>';
                    }
                }

                ?>


            </div>

        </div>

    </div>

</div>

<div id="testimonials" style="margin-bottom: 100px;color: #000;background-color: #ccc">

    <div class="container">

        <div class="row">

            <div class="col-lg-12 mt-3 pb-5 pt-5">

                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <div class="carousel-caption-testimonials">
                                <div class="row">

                                    <div class="col-lg-2">
                                        <?php

                                        if (!empty($principal[0]['Image'])) {
                                            echo '<img class="img-thumbnail" src="' . base_url() . $principal[0]['Image'] . '">';
                                        } else {
                                            echo '<img src="' . base_url() . 'assets/assets/images/Andy-Hadfield-Profile-SQUARE-Low-Res.jpg" class="img-thumbnail">';
                                        }

                                        ?>

                                    </div>

                                    <div class="col-lg-10">
                                        <p><?= $principal[0]['Message'] ?></p>
                                        <h5><?= $principal[0]['Name'] ?></h5>
                                        <h6>Principal - SBS Srinagar</h6>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="carousel-caption-testimonials">
                                <div class="row">

                                    <div class="col-lg-2">
                                        <?php

                                        if (!empty($vprincipal[0]['Image'])) {
                                            echo '<img class="img-thumbnail" src="' . base_url() . $vprincipal[0]['Image'] . '">';
                                        } else {
                                            echo '<img src="' . base_url() . 'assets/assets/images/Andy-Hadfield-Profile-SQUARE-Low-Res.jpg" class="img-thumbnail">';
                                        }

                                        ?>

                                    </div>

                                    <div class="col-lg-10">
                                        <p><?= $vprincipal[0]['Message'] ?></p>
                                        <h5><?= $vprincipal[0]['Name'] ?></h5>
                                        <h6>Vice Principal - SBS Srinagar</h6>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

</div>

<?php
    $this->load->view("frontend/footer");
?>

<!--JAVASCRIPT-->
<script src="<?= base_url(); ?>assets/assets/js/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="<?= base_url(); ?>assets/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/scrollreveal.js/3.1.4/scrollreveal.min.js"></script>
<!--JAVASCRIPT-->

<script>


    $(document).ready(function () {


        //Function to animate slider captions
        function doAnimations(elems) {
            //Cache the animationend event in a variable
            var animEndEv = 'webkitAnimationEnd animationend';

            elems.each(function () {
                var $this = $(this),
                    $animationType = $this.data('animation');
                $this.addClass($animationType).one(animEndEv, function () {
                    $this.removeClass($animationType);
                });
            });
        }

        //Variables on page load
        var $myCarousel = $('.carousel'),
            $firstAnimatingElems = $myCarousel.find('.carousel-item:first').find("[data-animation ^= 'animated']");

        //Initialize carousel
        $myCarousel.carousel();

        //Animate captions in first slide on page load
        doAnimations($firstAnimatingElems);

        //Pause carousel
        $myCarousel.carousel('pause');


        //Other slides to be animated on carousel slide event
        $myCarousel.on('slide.bs.carousel', function (e) {
            var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
            doAnimations($animatingElems);
        });


        /***
         * SCROLL ANIMATIONS
         * **/


        window.sr = ScrollReveal({reset: true});

        sr.reveal("#events .card .col-lg-4", {duration: 2000, origin: 'left'});
        sr.reveal("#events .card .col-lg-8", {duration: 2000, origin: 'left'});
        sr.reveal("#latest_visits .card", {duration: 2000, origin: 'left'});
        /***
         * SCROLL ANIMATIONS
         * **/


    });


</script>


</body>

</html>