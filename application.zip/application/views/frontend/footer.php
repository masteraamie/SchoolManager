<!--footer starts here-->
<style>
    #footer {
        background-color: #174b81 !important;
        color: #ffffff !important;
    }
</style>


<center>


    <div id="footer">

        <div class="container">
            <div class="row pt-4 pb-4">
                <div class="col-lg-12 pr-0">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                            data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                            aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="content_wrap">
                        <div class="logo">
                            <a href="index.php">
                                <img src="<?= base_url(); ?>assets/images/logo_footer.png" alt="" width="259px"
                                     height="86px">
                            </a>
                        </div>
                        <div class="contacts_address">
                            <address class="address_right">
                                <i class="fa fa-phone pt-2"></i> 0194-2315152<br>
                                <i class="fa fa-fax pt-2"></i> 0194-2315152
                            </address>
                            <address class="address_left">
                                Nowgam Bye-pass, Srinagar 190003<br>
                                Jammu and Kashmir
                            </address>
                        </div>

                        <br>
                        <div class="sc_socials sc_socials_size_small">
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_facebook">
                                    <span class="sc_socials_hover social_facebook"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_pinterest">
                                    <span class="sc_socials_hover social_pinterest"></span>
                                </a>
                            </div>
                            <br>
                            <img src="<?= base_url(); ?>assets/images/payments.png"
                                 alt="Online Fee Payment By Credit , debit card">
                        </div>
                    </div>


                </div>
            </div>
        </div>

    </div>
    <div class="copyright_wrap" style="padding: 10px;">
        <div class="content_wrap">
            <p>Copyright &copy;&nbsp;All&nbsp;Rights&nbsp;Reserved&nbsp;Srinagar&nbsp;British&nbsp;School&nbsp; <div class="col-lg-12 text-center">
            <p style="color: #000">Powered By :<a href="http://elancetechnologies.com" style="color: #ccc"> <img src="<?=base_url()?>assets/images/elance.png" alt="elance technologies"></a></p>
        </div>
        </div>
    </div>
</center>
<!-- footer end here-->