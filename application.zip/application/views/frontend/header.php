<div id="header">
    <div class="top-links" style="background: #ffffff">
        <div class="container">
            <div class="row pt-2 pb-2" style="font-size: 13px">
                <div class="col-lg-6 pt-1"><i class="fa fa-phone pt-2"></i> 0194-2315152</div>
                <div class="col-lg-6 text-left text-lg-right">
                    <a href="<?= base_url('FrontendController/pay_fee')?>" class="d-inline-block text-white bg-primary p-2">Pay Fee Online</a>
                    <a href="<?=base_url("StudentLogin/")?>" class="d-inline-block text-white bg-danger p-2">Campus Manager</a>
                    <a href="<?=base_url("TeacherLogin/")?>" class="d-inline-block text-white bg-info p-2">Staff Login</a>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row pt-4 pb-4">
            <div class="col-lg-3">
                <a href="<?=base_url();?>"><img src="<?=base_url();?>assets/assets/images/logo.png"></a>
            </div>
            <div class="col-lg-9 pr-0">
                <nav class="navbar pr-1 navbar-toggleable-md navbar-light bg-faded mt-2 justify-content-end" style="background: transparent">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown justify-content-end">
                        <ul class="navbar-nav justify-content-end" style="width: 100%">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    School
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="<?=base_url().'FrontendController/about_school'?>">About School</a>
                                    <a class="dropdown-item" href="<?=base_url().'FrontendController/school_song'?>">School Song</a>
                                    <a class="dropdown-item" href="#">Privacy Policy</a>
                                    <a class="dropdown-item" href="#">Parent Teacher Body</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Activities
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
                                    <a class="dropdown-item" href="<?=base_url().'FrontendController/achievements'?>">Achievements</a>
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/news')?>">News</a>
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/visits')?>">Visits</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Downloads
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink3">
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/assignments')?>">Assignment</a>
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/datesheets')?>">Date Sheet</a>
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/syllabi')?>">Syllabus</a>
                                    <a class="dropdown-item" href="<?= base_url('FrontendController/planners')?>">Academic Planners</a>
                                    <a class="dropdown-item" href="#">E-Lessons</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?=base_url().'FrontendController/events'?>">Events</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Libraries
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink4">
                                    <a class="dropdown-item" href="#">Latest Arrivals</a>
                                    <a class="dropdown-item" href="#">E-Resources</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Careers
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink5">
                                    <a class="dropdown-item" href="<?=base_url().'FrontendController/careers'?>">Register</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?=base_url().'FrontendController/contact'?>">Contact</a>
                            </li>
                        </ul>
                    </div>
                </nav>

            </div>
        </div>
    </div>
</div>