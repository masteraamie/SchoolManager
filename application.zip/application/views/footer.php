<div id="footer" style="background-color: #fff;position: fixed;bottom: 0;width: 100%;padding: 1px 0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <p style="color: #000">Powered By :<a href="http://elancetechnologies.com" style="color: #ccc"> <img src="<?=base_url()?>assets/images/elance.png" alt="elance technologies"></a></p>
            </div>
        </div>
    </div>
</div>