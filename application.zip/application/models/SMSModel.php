<?php

class SMSModel extends CI_Model
{

    const TABLE_PARENT_DETAILS = 'tbl_parent_details';
    const TABLE_STUDENT_DETAILS = 'tbl_student_details';

    //SMS FUNCTIONS
    public function add_admin($data)
    {
        if($data['SectionID'] == 0 && $data['ClassID'] == 0)
        {
            $this->db->select('*')->from($this::TABLE_STUDENT_DETAILS);

            $res = $this->db->get();

            $students = $res->result_array();

            $contacts = array();
            foreach ($students as $s)
            {
                $contacts[] = $s['Contact'];
            }


            $this->send_sms($contacts , $data['Message']);

            $this->db->select('*')->from($this::TABLE_PARENT_DETAILS);

            $res = $this->db->get();

            $parents = $res->result_array();

            $contacts = array();
            foreach ($parents as $p)
            {
                $contacts[] = $p['Contact'];
            }

            $this->send_sms($contacts , $data['Message']);
        }
        else
        {
            if($data['SectionID'] == 0)
            {
                $this->db->where("ClassID" , $data['ClassID']);
                $this->db->select('*')->from($this::TABLE_STUDENT_DETAILS);

                $res = $this->db->get();

                $students = $res->result_array();

                $contacts = array();
                foreach ($students as $s)
                {
                    $contacts[] = $s['Contact'];
                }
            }
        }



    }


    public function send_sms($mobile, $message)
    {
        $username = 'masteraamie@gmail.com';
        $hash = '43278912da2733712991ab15a47a4a4f25a1ba3806d53d7cb01fc8a866cdc604';

        // Message details
        $numbers = $mobile;
        $sender = urlencode('TXTLCL');
        $message = rawurlencode($message);


        // Prepare data for POST request
        $data = array('username' => $username, 'hash' => $hash, 'numbers' => $numbers, "sender" => $sender, "message" => $message);

        // Send the POST request with cURL
        $ch = curl_init('http://api.textlocal.in/send/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        // Process your response here
        //echo "<script>alert('$response');</script>";
    }
}